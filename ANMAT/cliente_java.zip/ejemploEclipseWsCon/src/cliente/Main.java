package cliente;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.inssjp.mywebservice.business.ConfirmacionTransaccionDTO;
import com.inssjp.mywebservice.business.MedicamentosDTO;
import com.inssjp.mywebservice.business.MedicamentosDTODHSerie;
import com.inssjp.mywebservice.business.TransaccionesNoConfirmadasWSResult;
import com.inssjp.mywebservice.business.WebServiceConfirmResult;
import com.inssjp.mywebservice.business.WebServiceError;
import com.inssjp.mywebservice.business.WebServiceResult;


public class Main extends JFrame implements ActionListener {
	
	private static WebService servicio;	
	private static MedicamentosDTO[] medicamentos = new MedicamentosDTO[1];
	private static MedicamentosDTODHSerie[] medicamentosDHSerie = new MedicamentosDTODHSerie[1];
	private static final String usuarioLaboratorio1 = "pruebasws";
	private static final String passLaboratorio1 = "pruebasws";
	private static String glnLaboratorio1 = "glnws";
	private static String usuarioLaboratorio2 = "9999999999918";
	private static String glnLaboratorio2 = "9999999999918";
	private static String passLaboratorio2 = "Pami1111";
	private static String glnDistribuidora = "9999999999925";
	private static String ultimoUsuarioUsado = Main.usuarioLaboratorio1;
	private static String ultimoPassUsado = Main.passLaboratorio1;
	private JComboBox transaccionesNoConfirmadas;
	private JTextField nroSerie;
	private JTextField nroSerieDesde;
	private JTextField nroSerieHasta;
	private JTextField nroTransaccion;
	private String transaccionSeleccionada = "--";
	private JButton refrescarCombo;
	
	private WebServiceResult enviarMedicamento() throws Exception  {	
		servicio = new WebService();
		MedicamentosDTO medicamento1 = new MedicamentosDTO();
		medicamento1.setF_evento("02/03/2013");
		medicamento1.setH_evento("13:15");
		medicamento1.setGln_origen(Main.glnLaboratorio2);//LABORATORIO
		medicamento1.setGln_destino(Main.glnLaboratorio1);//LABORATORIO
		medicamento1.setCuit_origen("20259171289");
		medicamento1.setCuit_destino("20259171289");
		medicamento1.setN_remito("R000100001234");
		medicamento1.setN_factura("A000100001234");
		medicamento1.setVencimiento("02/05/2011");
		medicamento1.setGtin("GTIN2");
		medicamento1.setLote("1");
		medicamento1.setId_evento("133");//DISTRIBUCION DEL PRODUCTO A UN ESLABON POSTERIOR
		if(nroSerie.getText().trim().isEmpty()){
			medicamento1.setNumero_serial("14851819833");//EL NUMERO DE SERIE DEBE SER DISTINTO EN CADA EJECUCION
		}
		else{
			validaCampoNumerico(nroSerie.getText().trim());
			medicamento1.setNumero_serial(nroSerie.getText().trim());
		}
		medicamentos[0] = medicamento1;
		return servicio.sendMedicamentos(medicamentos, Main.usuarioLaboratorio2, Main.passLaboratorio2);				
	}
	
	private WebServiceResult enviarMedicamentoDHSerie() throws Exception {		
		servicio = new WebService();		
		MedicamentosDTODHSerie medicamento1 = new MedicamentosDTODHSerie();
		medicamento1.setF_evento("02/03/2013");
		medicamento1.setH_evento("13:15");
		medicamento1.setGln_origen(Main.glnLaboratorio1);//LABORATORIO
		medicamento1.setGln_destino(Main.glnDistribuidora);//DISTRIBUIDORA
		medicamento1.setCuit_origen("20259171289");
		medicamento1.setCuit_destino("20259171289");
		medicamento1.setN_remito("R000100001234");
		medicamento1.setN_factura("A000100001234");
		medicamento1.setVencimiento("02/05/2011");
		medicamento1.setGtin("GTIN2");
		medicamento1.setLote("1");
		medicamento1.setId_evento("127");//DISTRIBUCION DEL PRODUCTO A UN ESLABON ANTERIOR
		if(nroSerieDesde.getText().trim().isEmpty()){
			medicamento1.setDesde_numero_serial("148518198267");
		}
		else{
			validaCampoNumerico(nroSerieDesde.getText().trim());
			medicamento1.setDesde_numero_serial(nroSerieDesde.getText().trim());
		}
		
		if(nroSerieHasta.getText().trim().isEmpty()){
			medicamento1.setHasta_numero_serial("148518198268");
		}
		else{
			validaCampoNumerico(nroSerieHasta.getText().trim());
			medicamento1.setHasta_numero_serial(nroSerieHasta.getText().trim());
		}
		medicamentosDHSerie[0] = medicamento1;
		return servicio.sendMedicamentosDHSerie(medicamentosDHSerie, Main.usuarioLaboratorio1, Main.passLaboratorio1);				
	}
	
	private WebServiceResult enviarCancelacTransacc() throws Exception {		
		servicio = new WebService();		
		long cod_transac = 12962963;	
		if(!nroTransaccion.getText().trim().isEmpty()){
			validaCampoNumerico(nroTransaccion.getText().trim());
			cod_transac = Long.parseLong(nroTransaccion.getText().trim());
		}		
		return servicio.sendCancelacTransacc(cod_transac, Main.ultimoUsuarioUsado, Main.ultimoPassUsado);				
	}
	
	private WebServiceConfirmResult confirmarTransaccion() throws Exception {				
		servicio = new WebService();	
		return servicio.confirmarTransaccion(obtenerTransaccionPendiente(), Main.usuarioLaboratorio1, Main.passLaboratorio1);					
	}
	
	public Main() {		
		super("Web Services");
		setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		setLayout(new FlowLayout(FlowLayout.LEFT, 10, 20));
		JLabel labelDescSendMed = new JLabel("El LABORATORIO 2 le manda medicamentos al LABORATORIO 1");
		add(labelDescSendMed);
		add(panelSendMedicamentos());
		JLabel labelDescSerie = new JLabel("El LABORATORIO de 1 le manda medicamentos la DISTRIBUIDORA");
		add(labelDescSerie);
		add(panelSendMedicamentoSerie());
		JLabel labelDescCancela = new JLabel("Cancela la transacci�n seleccionada");
		add(labelDescCancela);
		add(panelCancelarTransaccion());
		JLabel labelDescConf = new JLabel("El LABORATORIO 1 confirma la recepcion del medicamento enviado por el LABORATORIO 2");
		add(labelDescConf);
		add(panelConfirmarTransaccion());
		setSize(700,400);	
		setVisible(true);
	}

	private JPanel panelSendMedicamentos() {		
		JPanel panelSendMedicamentos= new JPanel(); 
		JButton sendMedicamentos = new JButton("Send Medicamentos");
		sendMedicamentos.addActionListener(this);	
		JLabel labelNroSerie = new JLabel("Nro Serie");
		nroSerie = new JTextField(10);	
		panelSendMedicamentos.add(labelNroSerie);
		panelSendMedicamentos.add(nroSerie);
		panelSendMedicamentos.add(sendMedicamentos);
		return panelSendMedicamentos;		
	}
	
	private JPanel panelSendMedicamentoSerie() {		
		JPanel panelSendMedicamentoSerie= new JPanel(); 
		JButton sendMedicamentoSerie = new JButton("Send Medicamentos serie");
		sendMedicamentoSerie.addActionListener(this);
		JLabel labelNroSerieDesde = new JLabel("Nro Serie Desde");
		nroSerieDesde = new JTextField(10);			
		JLabel labelNroSerieHasta = new JLabel("Nro Serie Hasta");
		nroSerieHasta = new JTextField(10);			
		panelSendMedicamentoSerie.add(labelNroSerieDesde);
		panelSendMedicamentoSerie.add(nroSerieDesde);
		panelSendMedicamentoSerie.add(labelNroSerieHasta);
		panelSendMedicamentoSerie.add(nroSerieHasta);
		panelSendMedicamentoSerie.add(sendMedicamentoSerie);
		return panelSendMedicamentoSerie;		
	}
	
	private JPanel panelCancelarTransaccion() {
		JPanel panelCancelarTransaccion= new JPanel(); 
		JButton cancelarTransaccion = new JButton("Cancelar Transacci�n");
		cancelarTransaccion.addActionListener(this);	
		JLabel labelCodigoTransaccion = new JLabel("C�digo de Transaccion");
		nroTransaccion = new JTextField(10);	
		panelCancelarTransaccion.add(labelCodigoTransaccion);
		panelCancelarTransaccion.add(nroTransaccion);
		panelCancelarTransaccion.add(cancelarTransaccion);
		return panelCancelarTransaccion;			
	}	
	
	private JPanel panelConfirmarTransaccion() {		
		JPanel panelTransPend= new JPanel(); 
		transaccionesNoConfirmadas = new JComboBox(obtenerIdsTransaccionesNoConfirmadas());
		transaccionesNoConfirmadas.addItem(transaccionSeleccionada);	
		transaccionesNoConfirmadas.setSelectedItem(transaccionSeleccionada);
		JLabel labelTrans = new JLabel("Transacciones no confirmadas");
		JButton confirmarTransaccion = new JButton("Confirmar Recepci�n");
		confirmarTransaccion.addActionListener(this);		
		refrescarCombo = new JButton("Refrescar transacciones");
		refrescarCombo.addActionListener(this);
		refrescarCombo.setEnabled(false); 
		panelTransPend.add(labelTrans);
		panelTransPend.add(transaccionesNoConfirmadas);
		panelTransPend.add(confirmarTransaccion);
		panelTransPend.add(refrescarCombo);
		return panelTransPend;		
	}		
	
	
	public static void main(String[] args) throws Exception {
		new Main();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String s = (String)e.getActionCommand();
		
		if(s.equals("Send Medicamentos")) {
			SendMedicamentos();
		}
		
		if(s.equals("Send Medicamentos serie")) {
			SendMedicamentoSerie();
		}
		
		if(s.equals("Cancelar Transacci�n")) {
			CancelarOperacion();
		}
		
		if(s.equals("Confirmar Recepci�n")) {
			ConfirmarRecepcion();
		}
		
		if(s.equals("Refrescar transacciones")) {
			refrescarTransacciones();
		}
	}

	private void SendMedicamentos() {
		WebServiceResult resultado = null;
		try {
			resultado = enviarMedicamento();
		} catch (Exception e1) {
			procesarErrores(e1.getMessage());
		}
		nroSerie.setText("");
		if(procesarResultado(resultado)){
			nroTransaccion.setText(resultado.getCodigoTransaccion());	
			refrescarCombo.setEnabled(true);
			Main.ultimoUsuarioUsado = Main.usuarioLaboratorio2;
			Main.ultimoPassUsado = Main.passLaboratorio2;
		}		
	}
	
	private void SendMedicamentoSerie() {
		WebServiceResult resultado = null;
		try {
			resultado = enviarMedicamentoDHSerie();
		} catch (Exception e1) {
			procesarErrores(e1.getMessage());
		}
		nroSerieDesde.setText("");
		nroSerieHasta.setText("");
		if(procesarResultado(resultado)){			
			nroTransaccion.setText(resultado.getCodigoTransaccion());
			Main.ultimoUsuarioUsado = Main.usuarioLaboratorio1;
			Main.ultimoPassUsado = Main.passLaboratorio1;
		}
	}
	
	private void CancelarOperacion() {
		WebServiceResult resultado = null;
		try {
			resultado = enviarCancelacTransacc();
		} catch (Exception e1) {
			procesarErrores(e1.getMessage());
		}
		procesarResultado(resultado);
		nroTransaccion.setText("");
	}
	
	private void ConfirmarRecepcion() {
		if((String)transaccionesNoConfirmadas.getSelectedItem() == "--"){
			JOptionPane.showMessageDialog(null, "Debe seleccionar una opci�n", "Advertencia", JOptionPane.WARNING_MESSAGE);
			return;
		}
		WebServiceConfirmResult resultado = null;		
		try {
			resultado = confirmarTransaccion();
			resultado.setCodigoTransaccion(resultado.getId_transac_asociada());
		} catch (Exception e1) {
			procesarErrores(e1.getMessage());
		}
		procesarResultado(resultado);
		transaccionesNoConfirmadas.removeItem(transaccionesNoConfirmadas.getSelectedItem());
		transaccionesNoConfirmadas.setSelectedItem(transaccionSeleccionada);
	}
	
	private boolean procesarResultado(WebServiceResult resultado) {
		boolean correcto = false;
		if(resultado!=null){
			if(resultado.getResultado()){
				JOptionPane.showMessageDialog(null, "Transaccion Exitosa c�digo:" + resultado.getCodigoTransaccion(), "Confirmaci�n", JOptionPane.INFORMATION_MESSAGE);
				correcto = true;
			}
			else{
				WebServiceError[] lst_errores = resultado.getErrores();
				for (int i=0; !resultado.getResultado() &&  i<lst_errores.length; i++) {
					JOptionPane.showMessageDialog(null, "[" + lst_errores[i].get_c_error() + "] " + lst_errores[i].get_d_error(), "Advertencia", JOptionPane.WARNING_MESSAGE);
				}
			}
		}	
		return correcto;
	}
	
	private TransaccionesNoConfirmadasWSResult obtenerTransaccionesNoConfirmadas() {
		TransaccionesNoConfirmadasWSResult resultado = null;
		servicio = new WebService();
		try {
			resultado = servicio.getTransaccionesNoConfirmadas(Main.usuarioLaboratorio1, Main.passLaboratorio1,-1, null, Main.glnLaboratorio2, Main.glnLaboratorio1, null, -1, null, null, null, null, null, null, null, null, -1,null, null);
			if(resultado.getList() == null){
				generarTransaccionPendiente();
				resultado = servicio.getTransaccionesNoConfirmadas(Main.usuarioLaboratorio1, Main.passLaboratorio1,-1, null, Main.glnLaboratorio2, Main.glnLaboratorio1, null, -1, null, null, null, null, null, null, null, null, -1, null, null);
			}
			
			if(resultado.getErrores() != null){
				WebServiceError[] lst_errores = resultado.getErrores();
				for (int i=0; i<lst_errores.length; i++) {
					JOptionPane.showMessageDialog(null, "[" + lst_errores[i].get_c_error() + "] " + lst_errores[i].get_d_error(), "Advertencia", JOptionPane.WARNING_MESSAGE);
				}
			}
		} catch (Exception e1) {
			procesarErrores(e1.getMessage());
		}
		return resultado;
	}
	
	private String [] obtenerIdsTransaccionesNoConfirmadas(){
		TransaccionesNoConfirmadasWSResult resultado = obtenerTransaccionesNoConfirmadas();
		ArrayList<String> idsTransacciones = new ArrayList<String>();
		if(resultado.getList() !=null){
			for (int i=0; i<resultado.getList().length; i++) {
				idsTransacciones.add(resultado.getList()[i].get_id_transaccion());
			}
		}
		String[] arrayIds = new String[idsTransacciones.size()];
		return (String[]) idsTransacciones.toArray(arrayIds);
	}
	
	private void refrescarTransacciones() {
		transaccionesNoConfirmadas.removeAllItems();
		transaccionesNoConfirmadas.setModel(new DefaultComboBoxModel(obtenerIdsTransaccionesNoConfirmadas()));
		transaccionesNoConfirmadas.addItem(transaccionSeleccionada);
		transaccionesNoConfirmadas.setSelectedItem(transaccionSeleccionada);
		refrescarCombo.setEnabled(false);
	}
	
	private ConfirmacionTransaccionDTO[] obtenerTransaccionPendiente(){
    	ConfirmacionTransaccionDTO[] confirmacionTransac = new ConfirmacionTransaccionDTO[1];
    	ConfirmacionTransaccionDTO transaccion = new ConfirmacionTransaccionDTO();
    	transaccion.setP_ids_transac(Long.parseLong((String)transaccionesNoConfirmadas.getSelectedItem()));
    	Date fechaOperacion = new Date();
    	DateFormat df = new SimpleDateFormat("dd/MM/yyyy");    	
    	transaccion.setF_operacion(df.format(fechaOperacion));
        confirmacionTransac[0] = transaccion;
        return confirmacionTransac;
    }
	
	private void procesarErrores(String errorMessage){
		JOptionPane.showMessageDialog(null, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
	}	
	
	private WebServiceResult generarTransaccionPendiente() throws Exception{
		//Solo para que halla una transacci�n pendiente de confirmaci�n y poder probar dicho m�todo
		servicio = new WebService();
		MedicamentosDTO medicamento2 = new MedicamentosDTO();
		medicamento2.setF_evento("02/03/2013");
		medicamento2.setH_evento("13:15");
		medicamento2.setGln_origen(Main.glnLaboratorio2);//LABORATORIO
		medicamento2.setCuit_origen("20259171289");
		medicamento2.setGln_destino(Main.glnLaboratorio1);//LABORATORIO
		medicamento2.setCuit_destino("20259171289");
		medicamento2.setN_remito("R000100001234");
		medicamento2.setN_factura("A000100001234");
		medicamento2.setVencimiento("02/05/2011");
		medicamento2.setGtin("GTIN2");
		medicamento2.setLote("1");
		medicamento2.setId_evento("133");	
		Random r = new Random();
		int serial = 5283 + r.nextInt(999999999-5283);
		medicamento2.setNumero_serial(Integer.toString(serial));
		medicamentos[0] = medicamento2;		
		WebServiceResult resultado = null;
		try {			
			resultado = servicio.sendMedicamentos(medicamentos, Main.glnLaboratorio2, Main.passLaboratorio2);	
			if(resultado.getErrores() == null){
				return resultado;
			}
		} catch (Exception e1) {
			procesarErrores("No se pudieron generar transacciones pendientes para confirmar");
		}
		return resultado;
	}
	
	private void validaCampoNumerico(String text) throws Exception{
		try{
			Long.parseLong(text);
		}catch(Exception ex){
			throw new Exception("El campo debe ser num�rico");
		}		
	}
}

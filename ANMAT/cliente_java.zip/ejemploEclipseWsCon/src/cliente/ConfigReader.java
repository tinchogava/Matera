package cliente;

import java.io.File;
import java.util.Hashtable;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class ConfigReader {
	
	private static String isProduccion;
	private static String usr;
	private static String pass;
	
	
	public ConfigReader() {
		ReadFile();
	}
	
	private void ReadFile() {
		
		File dir1 = new File (".");
	    String path ="";
	    try {
	       path = dir1.getCanonicalPath() + "/resources/";
	       }
	     catch(Exception e) {
	       e.printStackTrace();
	       }
	    String xmlFileName = path + "configurationStrings.xml";
	    //System.out.println (xmlFileName);
		File archivo = new File(xmlFileName);
		Hashtable<String, String> ht = new Hashtable<String, String>();
	    try {
	    	SAXReader saxReader = new SAXReader();
	    	Document document = saxReader.read(archivo);
	    	
	    	Element root = document.getRootElement();
	    	
	    	// iterate through child elements of root
	        for ( Iterator<?> i = root.elementIterator(); i.hasNext(); ) {
	        	Element element = (Element) i.next();
	        	
	        	for ( Iterator<?> i2 = element.elementIterator(); i2.hasNext(); ) {
	        		Element foo = (Element) i2.next();
	        		ht.put(foo.getName(), foo.getText());
	        	}
	        }
	        ConfigReader.isProduccion = (String)ht.get("isProduccion");
	        ConfigReader.usr = (String)ht.get("usr");
	        ConfigReader.pass = (String)ht.get("pass");
	    } catch(Exception e) {
	    	e.printStackTrace();
	    }
	      
	}
	
	public static String getPass() {
		return ConfigReader.pass;
	}

	public static String getIsProduccion() {
		return ConfigReader.isProduccion;
	}

	public static String getUsr() {
		return ConfigReader.usr;
	}

}

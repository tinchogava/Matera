package cliente;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;
import javax.xml.ws.Service;

import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.support.JaxWsEndpointImpl;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.handler.WSHandlerConstants;

import com.inssjp.mywebservice.business.ConfirmacionTransaccionDTO;
import com.inssjp.mywebservice.business.IWebService;
import com.inssjp.mywebservice.business.IWebServicePortType;
import com.inssjp.mywebservice.business.MedicamentosDTO;
import com.inssjp.mywebservice.business.MedicamentosDTODHSerie;
import com.inssjp.mywebservice.business.TransaccionesNoConfirmadasWSResult;
import com.inssjp.mywebservice.business.WebServiceConfirmResult;
import com.inssjp.mywebservice.business.WebServiceError;
import com.inssjp.mywebservice.business.WebServiceResult;



public class WebService {
	
	private static final String PATH_PAMI_PRODUCCION = "http://servicios.pami.org.ar/site/wsdl/prodmyservice.wsdl";
	private static final String PATH_PAMI_ENTRENAMIENTO = "https://servicios.pami.org.ar/trazamed.WebService?wsdl";
	private static final String targetNamespace = "http://business.mywebservice.inssjp.com/";
	private static final String webServiceName = "IWebService";
	private static final String wsdlFile = "resources/trazaMedWebService.wsdl";
	
	public WebService() {
		new ConfigReader();
	}
	
    @SuppressWarnings("deprecation")
	public WebServiceResult sendMedicamentos(MedicamentosDTO[] medicamentos, String usuario, String pass) throws Exception{
    	IWebServicePortType webService = configurarWebService();        
        WebServiceResult wsr = null;
        wsr = webService.sendMedicamentos(medicamentos, usuario, pass);    
        return wsr;	        
    }
    
    @SuppressWarnings("deprecation")
	public WebServiceResult sendMedicamentosDHSerie(MedicamentosDTODHSerie[] medicamentos, String usuario, String pass) throws Exception {    	
    	IWebServicePortType webService = configurarWebService();
        WebServiceResult wsr = null;
        wsr = webService.sendMedicamentosDHSerie(medicamentos, usuario, pass);	
        return wsr;       
    }
    
    @SuppressWarnings("deprecation")
	public WebServiceResult sendCancelacTransacc(Long codigo, String usuario, String pass) throws Exception {    	
    	IWebServicePortType webService = configurarWebService();       
        WebServiceResult wsr = null;
        wsr = webService.sendCancelacTransacc(codigo, usuario, pass);	
        return wsr;     
    }  
    
    @SuppressWarnings("deprecation")
   	public WebServiceConfirmResult confirmarTransaccion(ConfirmacionTransaccionDTO[] transaccionesPendientes, String usuario, String pass) throws Exception {    	
    	IWebServicePortType webService = configurarWebService();       
       	WebServiceConfirmResult wsr = null;
        wsr = webService.sendConfirmaTransacc(usuario, pass, transaccionesPendientes);	
        return wsr;     
    }  
    
    @SuppressWarnings("deprecation")
   	public TransaccionesNoConfirmadasWSResult getTransaccionesNoConfirmadas(String usuario, String pass, long idTransaccion, String glnInformador,
   			String glnOrigen, String glnDestino, String gtin, long idEvento, String fechaOpeDesde, String fechaOpeHasta, String fechaTransDesde, String fechaTransHasta,
   			String fechaVencimientoDesde, String fechaVencimientoHasta, String nroRemito, String nroFactura, long estadoTransaccion, String otro, String otro1) throws Exception {
    	IWebServicePortType webService = (IWebServicePortType) configurarWebService();       
       	TransaccionesNoConfirmadasWSResult wsr = null;    	
           wsr = webService.getTransaccionesNoConfirmadas(usuario, pass, idTransaccion, glnInformador, glnOrigen, glnDestino, gtin, idEvento, fechaOpeDesde, fechaOpeHasta, fechaTransDesde, 
           		fechaTransHasta, fechaVencimientoDesde, fechaVencimientoHasta, nroRemito, nroFactura, estadoTransaccion,otro,otro1);
           return wsr;  
   	}
      
    private IWebServicePortType configurarWebService() throws ServiceException, MalformedURLException {
    	String wsdl = this.getPathWsdl(ConfigReader.getIsProduccion());
    	URL wsdlURL = null;
        File wsdlFile = new File(WebService.wsdlFile);
        if (wsdlFile.exists()) {
            try {
				wsdlURL = wsdlFile.toURL();
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
        } else {
            try {
				wsdlURL = new URL(wsdl);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
        }
        QName qname = new QName(WebService.targetNamespace, WebService.webServiceName);
        Service service = Service.create(wsdlURL, qname);
        IWebServicePortType webService = service.getPort(IWebServicePortType.class);
        ConfigureSSLTrusted(webService);
        ConfigureHTTPSSoapHeaders(webService);           
        Client client = ClientProxy.getClient(webService);
        client.getInInterceptors().add(new LoggingInInterceptor());
        client.getOutInterceptors().add(new LoggingOutInterceptor());
        return webService;
	}

	private void ConfigureSSLTrusted(IWebServicePortType webService) {
    	
        java.security.Security.addProvider(new MyProvider());
        java.security.Security.setProperty("ssl.TrustManagerFactory.algorithm", "TrustAllCertificates");    
	    Client proxy = ClientProxy.getClient(webService);  
	    HTTPConduit conduit = (HTTPConduit) proxy.getConduit();  
	    TLSClientParameters tcp = new TLSClientParameters();  
	    tcp.setDisableCNCheck(Boolean.TRUE);  
	    conduit.setTlsClientParameters(tcp);
	    
    }
    
    @SuppressWarnings("unchecked")
	private void ConfigureHTTPSSoapHeaders(IWebServicePortType webService) {
    	
	    @SuppressWarnings("rawtypes")
		Map outProps = new HashMap();
	    outProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
	    outProps.put(WSHandlerConstants.USER, ConfigReader.getUsr());		    
	    outProps.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_TEXT);
	    outProps.put(WSHandlerConstants.PW_CALLBACK_CLASS, ClientPasswordCallback.class.getName());
	    WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(outProps);
	    Client client = ClientProxy.getClient(webService);
	    Endpoint cxfEndpoint = (JaxWsEndpointImpl) client.getEndpoint();
	    cxfEndpoint.getOutInterceptors().add(wssOut);
	}
    
    private String getPathWsdl(String valor) {
    	
    	String resultado = null;
    	if (valor != null) {
    		if (valor.toUpperCase().equals("TRUE")) {
    			resultado = WebService.PATH_PAMI_PRODUCCION;
    		} else if (valor.toUpperCase().equals("FALSE")) {
    			resultado =  WebService.PATH_PAMI_ENTRENAMIENTO;
    		}
    	}
    	return resultado;
    	
    }
}
